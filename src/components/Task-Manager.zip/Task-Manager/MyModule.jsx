import React from "react";
import Tabs from "./Tabs";
import TabsComponent from "./Tabs";


export default function TaskMyModule(){
    return(
    <>
   
  <TabsComponent/>
    </>
    );
}